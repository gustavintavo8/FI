money = float(input("Type the price: "))
distance = float(input("Type the distance: "))
age = int(input("Type the age: "))


free = (money >= 100) or (50 < money < 100 and distance <= 100) or (age > 65)

print("Free-delivery pizza: ", free)
