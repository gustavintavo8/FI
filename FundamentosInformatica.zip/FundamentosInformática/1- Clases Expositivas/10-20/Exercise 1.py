i = 0.5
r = 2
v = float(input("Type the potential difference: "))

v = i*r
i = v/r
r = v/i

print("I: %.2f, R: %.2f >> V: %.2f" % (i, r, v))
