name = input("Type your name: ")
height = float(input("Type your height: "))
mass = float(input("Type your mass: "))

BMI = mass / height*height

print("Dear %s,\n\tYour BMI is %.3f." % (name, BMI))
