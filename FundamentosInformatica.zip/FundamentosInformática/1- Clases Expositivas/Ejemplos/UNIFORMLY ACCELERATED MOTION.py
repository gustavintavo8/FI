# final_speed = initial_speed + a * t
i_s = 20
# a = 9.8
t = 30
f_s = 314

# f_s = i_s + a * t
# i_s = f_s - a * t
a = (f_s-i_s)/t
# t = (f_s-i_s)/a
print(a)

