a = 3
b = 7

c = (5 <= a <= 30) and (b % 2 == 0)
print(c)

d = not(5 <= a <= 30) and not(b % 2 == 0)
print(d)

e = (5 >= a >= 30) and (b % 2 == 1)
print(d)
