c = 10.7
f = (c*9/5)+32
print(f)

f2 = 77.9
c2 = (f2-32)*5/9
print(c2)

