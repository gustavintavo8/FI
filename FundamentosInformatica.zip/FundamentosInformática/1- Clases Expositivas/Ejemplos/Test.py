print("Goodbye world")
