def read_natural():
    x = int(input("Give me a positive integer: "))
    while x <= 0:
        x = int(input("Give me a positive integer: "))
    return x


print("Positive integer: ", read_natural())
