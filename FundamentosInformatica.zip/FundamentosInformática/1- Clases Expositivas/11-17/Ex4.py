def odd_multiple5(x):
    return (x % 2 != 0) & (x % 5 == 0)


a = 1
counter = 0
while a > 0:
    a = int(input("Give me a positive integer: "))

    if odd_multiple5(a):
        print(a, "is odd and multiple of 5")
        counter = counter + 1
    else:
        print("Not odd and multiple of 5")

print("The total provided numbers odd and multiple of 5 is:", counter)




