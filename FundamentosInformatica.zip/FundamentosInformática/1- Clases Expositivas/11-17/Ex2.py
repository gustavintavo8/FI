def multiple(x, y):
    if x % y == 0:
        return True
    else:
        return False


a = int(input("Give me a positive integer: "))
b = int(input("Give me another positive integer: "))
if multiple(a, b):
    print("Multiple")
else:
    print("Not multiple")

