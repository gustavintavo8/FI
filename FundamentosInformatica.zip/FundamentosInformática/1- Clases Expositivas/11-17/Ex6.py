def fib(n):
    x = 0
    y = 1

    if n <= 0:
        print("Give a positive input.")
    elif n == 1:
        print(y)
    else:
        for i in range(2, n):
            z = x + y
            x = y
            y = z
        print(z)


w = int(input("Give me a positive integer: "))
fib(w)
