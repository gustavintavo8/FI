a = int(input("1st number: "))
b = int(input("2nd number: "))
c = int(input("2nd number: "))

print(a, b, c)
if a != b and a != c and b != c:
    print("0")
elif a == b and a == c and b == c:
    print("20")
elif a == b or a == c or b == c:
    print("10")
