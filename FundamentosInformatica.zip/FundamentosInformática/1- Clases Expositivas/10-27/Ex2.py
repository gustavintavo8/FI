n1 = float(input("1st number: "))
n2 = float(input("2nd number: "))

if(n1 == 6) or (n2 == 6) or (n1+n2 == 6) or (n1-n2 == 6):
    print("pepe")
else:
    print("no pepe")
