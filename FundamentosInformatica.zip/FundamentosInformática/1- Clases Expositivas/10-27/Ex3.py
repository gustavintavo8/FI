n1 = int(input("1st number: "))
n2 = int(input("2nd number: "))

if 21-n1 < 0 or 21-n2 < 0:
    print("0")
elif 21-n1 < 21-n2:
    print(n1, "is the nearest")
elif 21-n2 < 21-n1:
    print(n2, "is the nearest")
else:
    print("0")

