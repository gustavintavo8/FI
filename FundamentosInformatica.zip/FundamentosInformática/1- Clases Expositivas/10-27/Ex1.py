f1 = float(input("front 1: "))
f2 = float(input("front 2: "))
r1 = float(input("rear 1: "))
r2 = float(input("rear 2: "))

if (f1 == f2) and (r1 == r2):
    print("pepe")
else:
    print("no pepe")
