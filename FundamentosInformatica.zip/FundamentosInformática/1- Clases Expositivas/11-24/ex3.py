def th_list(list, thres):
    newlist = [0 for i in range(len(list))]
    counter = 0
    for i in range(len(list)):
        if list[counter] > thres:
            newlist[i] = list[i]
        counter = counter + 1

    # for k in range(len(newlist)):
    #   if newlist[k] == 0:
    #      newlist.remove(k)

    # for k in newlist:
    #   if k == 0:
    #      newlist.remove(0)

    while 0 in newlist:
        newlist.remove(0)

    return newlist


my_list = [1, 5, 7, 2, 8, 10, 13, 15]
my_thres = int(input("Give me the threshold: "))
print(th_list(my_list, my_thres))

