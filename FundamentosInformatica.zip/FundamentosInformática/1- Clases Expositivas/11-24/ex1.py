string = [1, 4, 3, 8, 10, 7]
counter = 0

for i in string:
    if i % 5 == 0:
        counter = counter + 1
print(counter)
