string = [1, 4, 3, 8, 10, 7]
counter = 0

for i in range(len(string)):
    if string[i] % 5 == 0:
        string[i] = 'five'

print(string)
