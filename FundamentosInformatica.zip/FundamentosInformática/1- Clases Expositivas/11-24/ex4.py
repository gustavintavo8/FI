def transpose(matrix):

    matrix2 = [[0 for j in range(len(matrix))] for i in range(len(matrix[0]))]

    for j in range(len(matrix)):
        for i in range(len(matrix[0])):
            matrix2[i][j] = matrix[j][i]

    return matrix2


m = [[1, 2],
     [3, 4],
     [5, 6]]
w = transpose(m)
print(w)



