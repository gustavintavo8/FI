def decrement(val):
    val = val - 1
    return val


x = 7
print(x)
y = decrement(x)
print(x)
print(y)
