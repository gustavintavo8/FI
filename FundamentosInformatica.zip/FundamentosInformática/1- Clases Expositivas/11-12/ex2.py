def decrement_and_print(x):
    x = x-1
    print(x)

x = 10
y = 1
decrement_and_print(y)
