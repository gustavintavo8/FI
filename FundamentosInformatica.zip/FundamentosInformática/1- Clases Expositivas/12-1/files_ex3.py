def get_num(line):
    info = line.split(";")
    return int(info[2])


def get_inhabitants(filename):
    info2 = filename.split(";")
    return int(info2[1])


def get_countries(filename):
    info3 = filename.split(";")
    return info3[0]


def th_mobiles(filename, th):
    f = open(filename, "r")
    lines = f.readlines()
    f.close()
    string = []
    lines = lines[1:]
    for l in lines:
        if get_num(l)/get_inhabitants(l) <= th:
            string.append(get_countries(l))
    return string


print(th_mobiles("file.txt", 5))
