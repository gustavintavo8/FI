def get_num(line):
    info = line.split(";")
    return int(info[2])


def number_mobiles(filename):
    f = open(filename, "r")
    lines = f.readlines()
    f.close()

    total = 0
    lines = lines[1:]
    for l in lines:
        total += get_num(l)
    return total


def get_inhabitants(filename):
    info2 = filename.split(";")
    return int(info2[1])


def number_inhabitants(filename):
    f = open(filename, "r")
    lines = f.readlines()
    f.close()

    total = 0
    lines = lines[1:]
    for l in lines:
        total += get_inhabitants(l)
    return total


print("total inhabitants:", number_inhabitants("file.txt"))
print("total numbers:", number_mobiles("file.txt"))
