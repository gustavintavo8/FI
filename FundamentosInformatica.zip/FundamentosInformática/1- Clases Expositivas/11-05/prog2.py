import random

n = random.randint(1, 10)

print("n =", n)
x = 1
again = True

while again:
    print("x =", x)
    x = 2*x
    n = n/2
    if n<=1:
        again = False
