numcolumn = int(input("Give me the number of columns: "))

for i in range(1, 101):    ## i between 1 and 100.
    print(i, end=" ")
    if i % numcolumn == 0: ## If the number being printed is divisible by the number given,
        print("\n")        ## the program will continue in the following row.

