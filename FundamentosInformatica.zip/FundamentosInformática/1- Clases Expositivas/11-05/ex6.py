## Print all the numbers from 1-100

## Number % 3 == 0 ? --> Fizz
## Number % 5 == 0 ? --> Buzz
## Number % 3 == 0 and Number % 5 == 0 ? --> FizzBuzz
## otherwise --> Print the number

for i in range(1, 101):
    if i % 3 == 0:
        print("Fizz", end="")
    if i % 5 == 0:
        print("Buzz", end="")
    if i % 3 != 0 and i % 5 != 0:
        print(i, end="")
    print()
