def leer_lista():
    list = []
    n = 0
    while -50 <= n <= 50:
        n = int(input("Mete un número [-50, 50]: "))
        list.append(n)
    return list


def escala_lista(list, n):
    for i in range(len(list)):
        list[i] = list[i] * n
    return list


milistaleida = leer_lista()
print("La lista introducida es", milistaleida)
c = int(input("numero pa multiplicar: "))
print(escala_lista(milistaleida, c))
