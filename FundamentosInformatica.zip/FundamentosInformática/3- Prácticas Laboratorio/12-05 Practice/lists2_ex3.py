a = [1, 2, 1, 3, 2, 5, 6, 7]
b = []
for i in range(len(a)-1, -1, -1):
    b.append(a[i])
print(b)
