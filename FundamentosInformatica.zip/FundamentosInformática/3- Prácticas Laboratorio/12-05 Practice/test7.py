# Exercise 2 (3.75 points)
# ------------------------
# Create a function called formT that takes an integer 'base' greater than 3 and
# odd, an integer 'height' greater than 3, and prints a T form with asterisks,
# like the one seen in the example.
# Write a program that prompts the user for a base (greater than 3 and odd) and
# and a height (greater than 3) and prints a T form with them.

def formT(base, height):
    if base > 3 and base % 2 != 0 and height > 3:
        print(base*"*")
        for i in range(0, height):
            print(" "*((base-1)//2), end='*\n')
    else:
        print("Incorrect values")


my_base = int(input("Give me an integer number(greater than 3 and odd): "))
my_height = int(input("Give me an integer number(greater than 3): "))
formT(my_base, my_height)
# Example with base = 7 and height = 7
# ------------------------------------
# *******
#    *
#    *
#    *
#    *
#    *
#    *
