def sum_powers(list, n):
    sum = 0
    for i in list:
        sum = sum + pow(i, n)
    return sum


list = [1, 2, 3]
print(sum_powers(list, 2))
