result = '> '
for i in range(-2, 7, 1):
    if i % 2 == 0:
        result = result + str(i) + ' '
    else:
        result = result + str(i-1) + ' '

print(result)
