a = [1, 2, 1, 3, 2, 5, 6, 7]
oddcounter = 0
evencounter = 0
for i in a:
    if i % 2 == 0:
        evencounter = evencounter + 1
    else:
        oddcounter = oddcounter + 1

print("odd:", oddcounter)
print("even:", evencounter)
