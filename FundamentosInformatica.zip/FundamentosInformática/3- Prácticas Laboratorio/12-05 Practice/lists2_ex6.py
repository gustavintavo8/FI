def rotate_left(list):
    aux = list[0]
    del list[0]
    list.append(aux)
    return list


list = [1, 2, 3, 4, 5]
print(list)
print(rotate_left(list))
