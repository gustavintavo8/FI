import random


def random_list(th):
    list = []
    for i in range(0, th):
        number = random.randint(1, 20)
        list.append(number)
    return list


xd = random_list(10)
print(xd)
