a = 'b'
counter = 0
while a != '.':
    a = input("give me the letter: ")
    if a == 'a':
        counter = counter + 1
print(counter)
