# LeapYear
y = int(input("Give me the year: "))

if y % 4 == 0 and y % 100 != 0 or y % 400 == 0:
    print("true")
else:
    print("false")
