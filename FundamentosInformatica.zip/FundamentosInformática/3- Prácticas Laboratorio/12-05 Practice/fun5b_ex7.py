def line(ch, n):
    my_string = ""
    for i in range(0, n):
        my_string += ch
    return my_string


def square(ch, n):
    for i in range(0, n):
        print(2 * line(ch, n), end="\n")


ch = (input("Gimme ch: "))
n = int(input("Gimme n: "))
square(ch, n)
