def set_zeros(list):
    num_mod = 0
    for i in range(0, len(list)):
        if list[i] < 0:
            list[i] = 0
            num_mod = num_mod + 1
    return num_mod


data = [3, -4, 5, 7, -1, 8]
print(set_zeros(data))
print(data)
