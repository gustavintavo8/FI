N1 = float(input("N1: "))
N2 = float(input("N2: "))
N3 = (N1+N2)/2
print("la nota media es:", N3)

aprueba = False

if N3 >= 5:
    aprueba = True

if aprueba:
    print("el usuario aprueba")
else:
    print("no aprueba")
