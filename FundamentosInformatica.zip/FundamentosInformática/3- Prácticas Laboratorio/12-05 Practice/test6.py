def escala_lista(list, n):
    for i in range(len(list)):
        list[i] = list[i] * n
    return list


my_list = [1, 2, 3, 4]
print(escala_lista(my_list, 5))
