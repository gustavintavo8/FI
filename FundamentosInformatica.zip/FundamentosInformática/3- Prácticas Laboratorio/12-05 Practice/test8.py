# Exercise 3 (3.75 points)
# ------------------------
# Create a function called examSeriesList that takes a positive integer n as a
# parameter and returns a list with the first n numbers of the following series:
#   SE(0) = 7, SE(1) = 2
#   SE(n) = SE(n - 1) - (SE(n - 2)*2) if n > 1.


def examSeriesList(n):
    SE = []
    if n > 1:
        SE.append(7)
        SE.append(2)
        for i in range(2, n):
            SE.append(SE[i - 1] - (SE[i - 2] * 2))
    else:
        print("Invalid values")
    return SE


print(examSeriesList(10))
# Write a program that prompts the user for an integer n > 0 and:
# Create a list with the first n numbers of the exam series
# Print it

# Example with n = 10
# -------------------
# [7, 2, -12, -16, 8, 40, 24, -56, -104, 8]
