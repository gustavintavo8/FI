def sum_of_powers(list, n):
    sum = 0
    for i in list:
        sum = sum + pow(i, n)
    return sum


data = [1, 2, 3, 4]
print(sum_of_powers(data, 2))
