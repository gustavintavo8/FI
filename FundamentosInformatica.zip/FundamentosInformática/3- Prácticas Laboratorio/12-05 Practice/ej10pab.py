a = int(input("a: "))
n = int(input("n: "))
results = []
for x in range(0, n):
    sum_a = 0
    sum_b = 0
    for v in range(n-x, n):
        sum_a += v
    for w in range(0, x):
        sum_b += w
    if abs(sum_a - sum_b) == a:
        results.append(x)
print("The values that meet the condition are:", results)


