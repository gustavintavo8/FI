import random


def random_list(th):
    list = []
    for i in range(0, th):
        number = random.randint(1, 20)
        list.append(number)
    return list


list = random_list(10)
print(list)
th = int(input("th: "))
newlist = []
for i in list:
    if i < th:
        newlist.append(i)
print(newlist)
