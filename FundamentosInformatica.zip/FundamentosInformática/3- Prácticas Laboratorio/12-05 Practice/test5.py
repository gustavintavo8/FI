def rotate_left(list):
    temp = list[0]
    del list[0]
    list.append(temp)
    return list


my_list = [1, 2, 3, 4, 5, 6]
print(rotate_left(my_list))
