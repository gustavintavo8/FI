def line(ch, n):
    my_string = ""
    for i in range(0, n):
        my_string += ch
    return my_string


def empty_square(ch, n):
    for i in range(0, n):
        if i == 0 or i == n-1:
            print(2 * line(ch, n), end="\n")
        else:
            print(ch, ((2 * n)-4) * " ", ch)


ch = (input("Gimme ch: "))
n = int(input("Gimme n: "))
empty_square(ch, n)
