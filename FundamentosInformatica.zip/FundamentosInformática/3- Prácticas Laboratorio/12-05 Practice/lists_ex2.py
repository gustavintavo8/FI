def largest(list):
    largestpos = 0
    largestnum = 0
    for i in range(0, len(list)):
        if list[i] > largestnum:
            largestnum = list[i]
            largestpos = i
    return largestpos


list = [4, 2, 7, 1, 3]
print(largest(list))
