def sum_list(list):
    sum = 0
    for i in list:
        sum = sum + i
    return sum


list = [1, 2, 3]
print(sum_list(list))
print(sum(list))
