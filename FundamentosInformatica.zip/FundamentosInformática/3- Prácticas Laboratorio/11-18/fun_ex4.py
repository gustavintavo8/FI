def quali(x):
    if 0 <= x < 5:
        return "Fail"
    elif 5 <= x < 7:
        return "Pass"
    elif 7 <= x < 9:
        return "Good"
    elif 9 <= x < 10:
        return "Very good"
    elif x == 10:
        return "Excellent"


n = int(input("Give me the mark: "))
print(quali(n))
