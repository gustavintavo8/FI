def isLeap(year):
    if (year % 4 == 0) and (year % 100 != 0):
        return True
    else:
        if (year % 100 == 0) and (year % 400):
            return True
        else:
            return False


n = int(input("Give me the year: "))
print(isLeap(n))
