def read_integer():
    x = int(input("Give me a positive integer: "))
    return x


def greater(x, y):
    if x < y:
        return y
    else:
        return x


a = read_integer()
b = read_integer()

print("The greatest provided number is:", greater(a, b))
