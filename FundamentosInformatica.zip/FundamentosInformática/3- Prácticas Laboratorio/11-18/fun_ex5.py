def bmi():
    mass = float(input("Give me the mass: "))
    height = float(input("Give me the height: "))
    index = mass/(height*height)
    if index < 18.50:
        return "Underweight"
    elif 18.50 <= index < 25:
        return "Normal"
    elif 25 <= index < 30:
        return "Overweight"
    elif index >= 30:
        return "Obese"


print(bmi())
