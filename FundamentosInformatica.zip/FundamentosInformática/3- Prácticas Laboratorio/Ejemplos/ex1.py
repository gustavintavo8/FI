def subidas_ibex(lista1, lista2):
    countersubida = 0
    for i in range(0, len(lista1)):
        if lista2[i] > lista1[i]:
            countersubida += 1
    return countersubida


ayer = [1, 3, 5, 7]
hoy = [1, 2, 6, 8]
print(subidas_ibex(ayer, hoy))
