# LEARNING OUTCOME: Use a repetitive structure (while loop)
# IMPLEMENTATION: while cond:
#		           body
# DESCRIPTION: This program calculates the logarithm in base 2 of 16

x = 0
n = 16
while n%2 == 0:
    x = x+1
    n = n/2
print("x = %d" %x)
