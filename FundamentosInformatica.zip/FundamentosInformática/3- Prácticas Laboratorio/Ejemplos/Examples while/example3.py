# LEARNING OUTCOME: Use nested repetitive structures (while loop)
# IMPLEMENTATION: while cond1:
#		           sent1
#		           ...
#		           sentM
#                       while cond2:
#                             sent1
#                             ...
#                             sentN
#                       sentM+2
# DESCRIPTION: This program prints three rows of "*", each one formed
#              by five "*".

rows = 3
columns = 5
while rows != 0:
    i = 1
    while i <= columns:
        print("*", end="")
        i = i+1
    print()
    rows = rows-1
