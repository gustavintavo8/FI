# LEARNING OUTCOME: Use a repetitive structure (while loop)
# IMPLEMENTATION: while cond:
#		           body
# DESCRIPTION: This program calculates the sum of all the numbers that
#              are introduced by the keyboard, and ends when a 0 is
#              typed.

sum = 0
number = int(input("Type a number (0 to end): "))
while number != 0:
    sum = sum + number
    number = int(input("Type another number (0 to end): "))
print("The sum is: %d" %sum)
