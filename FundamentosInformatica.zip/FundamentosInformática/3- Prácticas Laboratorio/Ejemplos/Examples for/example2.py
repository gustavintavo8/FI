# LEARNING OUTCOME: Use a repetitive structure (for loop)
# IMPLEMENTATION: for i in range(ini, fin):
#		           body
# DESCRIPTION: This program reads a number (n>=0) and then calculates n!

fact = 1
n = int(input("Type an integer number (>=0): "))

while n<0:
    n = int(input("Type an integer number (>=0): "))

for i in range(1,n+1):
    fact = fact*i

print("The factorial of %d is %d" % (n, fact))
