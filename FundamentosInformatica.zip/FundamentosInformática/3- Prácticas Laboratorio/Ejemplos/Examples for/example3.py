# LEARNING OUTCOME: Use a repetitive structure (for loop)
# IMPLEMENTATION: for i in range(num):
#		           body
# DESCRIPTION: This program reads a number n (>=0) and prints a
# sequence of n "*". The value of the control variable is not relevant.
# The important thing is that the sentences of the loop are run n times.

n = int(input("Type an integer number (>=0): "))

while n<0:
    n = int(input("Type an integer number (>=0): "))

for i in range(n):
    print("*", end="")
print()
