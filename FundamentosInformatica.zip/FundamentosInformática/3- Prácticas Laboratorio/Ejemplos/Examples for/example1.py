# LEARNING OUTCOME: Use a repetitive structure (for loop)
# IMPLEMENTATION: for i in range(ini, fin, step):
#
# DESCRIPTION: This program shows different sequences of integers.

# Method 1: Print all the integers from 1 to 10, with three arguments
# in function range()
print("Method 1: Sequence of integers from 1 to 10:")
for i in range(1,11,1):
    print(i, end=" ")
print()

# Method 2: Print all the integers from 1 to 10, with two arguments
# in function range()
print("Method 2: Sequence of integers from 1 to 10:")
for i in range(1,11):
    print(i, end=" ")
print()

# Method 3: Print all the integers from 1 to 10, with one argumente
# in function range()
print("Method 3: Sequence of integers from 1 to 10:")
for i in range(10):
    print(i+1, end=" ")
print()

# Method 4: Print all the integers from 10 to 1
print("Method 4: Sequence of integers from 10 to 1:")
for i in range(10,0,-1):
    print(i, end=" ")
print()

# Method 5: Example of empty range since the initial value is lower than
# the final one and the step is -1
print("Method 5: Sequence of integers from 1 to 10 and step -1:")
for i in range(1,11,-1):
    print(i, end=" ")
print("Empty range!")

# Method 6: Example of empty range since the initial value is greater
# than the final one and the step is 1
print("Method 6: Sequence of integers from 10 to 1:")
for i in range(10,0,1):
    print(i, end=" ")
print("Empty range!")

# Method 7: Print all the even integer numbers from 1 to 10
print("Method 7: Sequence of even integers from 1 to 10:")
for i in range(2,11,2):
    print(i, end=" ")
print()

# Method 8: Print all the odd integer numbers from 1 to 10
print("Method 8: Sequence of odd integers from 1 to 10:")
for i in range(1,10,2):
    print(i, end=" ")
print()
