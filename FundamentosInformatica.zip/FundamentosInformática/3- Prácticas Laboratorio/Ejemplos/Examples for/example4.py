# LEARNING OUTCOME: Use nested repetitive structures (for loop)
# IMPLEMENTATION: for i in range(num):
#		           sent1
#		           ...
#		           sentm
#		           for j in range(num)
#		               sent1
#		               ...
#		               sentn
#		           sentm+2
# DESCRIPTION: This program prints n rows of m asteriks.

n = 3
m = 5
for i in range(n):
    for j in range(m):
        print("*", end="")
    print()
