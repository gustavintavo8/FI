# UO281798

sum = 0
for i in range(1, 101):
    x = ((i*i + 1) / i)
    sum = sum + x
print(sum)
