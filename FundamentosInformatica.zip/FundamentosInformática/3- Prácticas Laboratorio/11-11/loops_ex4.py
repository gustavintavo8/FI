#UO281798

n = int(input("Give me the first number: "))
a = int(input("Give me the second number: "))
sumdiv = 0
for i in range(1, n+1):
    for v in range(1, i + 1):
        if i % v == 0:
            sumdiv = sumdiv + 1
            if sumdiv == a:
                print(i)

