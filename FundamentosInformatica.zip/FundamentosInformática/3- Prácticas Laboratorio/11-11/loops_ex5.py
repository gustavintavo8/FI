# UO281798

n = int(input("Give me the number: "))

for i in range(1, n):
    summatory = 0
    j = i
    while j != 0:
        digit = j % 10
        digit3 = digit ** 3
        summatory = summatory + digit3
        j = j // 10

        if i == summatory:
            print(i, end=" ")

