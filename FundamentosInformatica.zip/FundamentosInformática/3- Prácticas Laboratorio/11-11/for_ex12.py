#UO281798

n = int(input("Give me the n: "))

# No sé guardar los valores de los divisores.
