#UO281798

a = int(input("Give me the lower number of the interval: "))
b = int(input("Give me the higher number of the interval: "))

for i in range(a, b):
    if(i == 0):
        print("i is Zero")
    elif (i%2 == 0):
        print(i, " Even")
    else:
        print(i, " Odd")

## Zero is considered Even by this code.
