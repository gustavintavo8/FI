#UO281798
for i in range (20, 9, -1):
    print(i)

