#UO281798

n = int(input("Give me the first number: "))
a = int(input("Give me the second number: "))
d = int(input("Give me the third number: "))

ans = 0
x = 0
while(x+d <= n):
    for i in range (x, x+d):
       ans = ans + x
       if ans == a:
            print(a)
       x = x+1

