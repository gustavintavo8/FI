#UO281798

n = int(input("Give me the n: "))

print("The divisors are: ", end=(' '))
for i in range(1, n+1):
    if (n % i == 0):
        print(i, end=' ')

