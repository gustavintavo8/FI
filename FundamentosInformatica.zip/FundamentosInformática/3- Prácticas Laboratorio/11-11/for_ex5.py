#UO281798
for i in range(40, 19, -2):
    print(i)
