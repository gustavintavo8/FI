# UO281798

sum = 0
a = int(input("Give me the lower bound: "))
b = int(input("Give me the upper bound: "))
for i in range(a, b):
    x = ((i*i + 1) / i)
    sum = sum + x
print(sum)
