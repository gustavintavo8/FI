#UO281798

m = int(input("Give me the first number: "))
n = int(input("Give me the second number: "))

for i in range(m):
    for j in range(n):
        print("*", end="")
    print()
