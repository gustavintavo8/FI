##UO281798

n = int(input("Give me the limit: "))
a, b =0, 1

while a < n: ## True while a doesn't equal n
    print(a, end=' ')
    a, b = b, a+b ## Update (a, b) to be (b, a+b) (Fibonacci sequence)
