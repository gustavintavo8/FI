#UO281798

n = int(input("Give me the number: "))

for i in range(n):
    for j in range(n):
        print("*", end="")
    print()
