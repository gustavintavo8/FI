#UO281798

a = int(input("Give me the a: "))
b = int(input("Give me the b: "))
sum = 0
for i in range(0, b):
    sum = sum + a
print("The multiplication is: ", sum)
