# UO281798

def is_prime(n):
    if n == 1 or n == 2:
        return True
    else:
        for i in range(2, n):
            if n % i == 0:
                return False
        return True


def how_many_prime(list):
    counter_prime = 0
    for i in list:
        if is_prime(i):
            counter_prime += 1
    return counter_prime


print(is_prime(8))
my_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print("In that list there are", how_many_prime(my_list), "prime numbers.")
