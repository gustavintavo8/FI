# UO281798

name = input("Give me your name: ")
surname = input("Give me your surnames: ")
age = int(input("Give me your age (in years): "))
height = int(input("Give me your height (in cm): "))

age_months = age*12
height_meters = height / 100

print(name, surname, "of", age_months, "months old, heights", height_meters, "meters.")
