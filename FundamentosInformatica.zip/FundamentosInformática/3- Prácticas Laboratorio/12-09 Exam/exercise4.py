# UO281798

def readMatches(filename):
    result = []
    home_win_counter = 0
    draw_counter = 0
    visitor_win_counter = 0
    f = open(filename, "r")
    lines = f.readlines()
    for i in lines:
        i = i.rstrip("\n")
        line_separated = i.split("-")
        a = int((line_separated[0]))
        b = int((line_separated[1]))
        if a > b:
            home_win_counter += 1
        if a < b:
            visitor_win_counter += 1
        if a == b:
            draw_counter += 1
    f.close()
    result.append(home_win_counter)
    result.append(draw_counter)
    result.append(visitor_win_counter)
    return result


print(readMatches("goals.txt"))
