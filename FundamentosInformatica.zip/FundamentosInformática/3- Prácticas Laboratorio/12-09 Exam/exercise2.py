# UO281798

def factorial(n):
    sum = 1
    while n > 0:
        sum *= n
        n -= 1
    return sum


n = int(input("Give me the entry: "))
while n <= 0:
    n = int(input("Invalid value. Give me the entry: "))

e = 0
while n > 0:
    e = e + 1/factorial(n)
    n = n - 1
e = e + 1
print(e)
