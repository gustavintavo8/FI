# UO281798

def createList(n):
    list = []
    if n <= 0:
        return list
    else:
        while n > 0:
            x = int(input("Give me a number: "))
            list.append(x)
            n = n - 1
    return list


w = int(input("How many numbers? "))
print(createList(w))
