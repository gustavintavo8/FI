def terminaen7(m):
    digit = m % 10
    if digit == 7:
        return True


def isPrime(n):
    a = n
    count = 0
    while a > 0:
        if n % a == 0:
            count = count + 1
        a = a - 1
    if count == 2:
        return True
    else:
        return False


x = int(input("Give me a real number: "))
y = int(input("Give me a real number: "))
counter = 0
for j in range(x, y+1):
    if isPrime(j) and terminaen7(j):
        print(j, end=', ')
        counter = counter + 1

print("El número de números primos que terminan en 7 es", counter, ".")

