#UO281798

counter = 0                                 # Generate a counter for the numbers that have only odd digits.
for i in range(1, 1000):                    # Creates a loop to check every number from 1 to 1000
    j = i                                   # The number gets "saved" in another variable to work with it without breaking the main loop.
    digitcounter = 0                        # General counter for the digits of the number
    oddcounter = 0                          # Counter for only the odd digits
    while j != 0:                           # Loop to check the number of digits and the number of odd digits.
        digit = j % 10
        j = j // 10
        digitcounter = digitcounter + 1
        if digit % 2 != 0:
            oddcounter = oddcounter + 1
    if digitcounter == oddcounter:          # The count of the digits and odd digits finish, we compare it and then step to the next number.
        counter = counter + 1               # If the number of digits equals the number of odd digits, it'll be counted in the main counter.
print(counter)
