# UO281798

age = int(input("What's your age?: "))                      # Here we ask for the age and store it in a variable "age"
inc = int(input("What's your income?: "))                   # Here we ask for the income and store it in a variable "inc"

if (age < 0) or (inc < 0):                                  # If the values are not correct, we'll keep asking for them.
    print("Those values are incorrect!")
elif age < 18:                                              # Here we define the case in which the user is minor and doesn't pay taxes.
    print("As you're minor, there are no taxes to pay.")
else:                                                       # Then, if the values are correct and the user is can pay taxes, the different cases will be defined with nested if's.
    if inc < 12500:
        if age < 30:
            print("Outcome: ", inc * 0.02, " as the percentage to apply is 2%")
        elif age >= 30:
            print("Outcome: ", inc * 0.05, " as the percentage to apply is 5%")
    elif 12500 <= inc < 25000:
        if age < 30:
            print("Outcome: ", inc * 0.04, " as the percentage to apply is 4%")
        elif age >= 30:
            print("Outcome: ", inc * 0.09, " as the percentage to apply is 9%")
    elif inc >= 25000:
        if age < 30:
            print("Outcome: ", inc * 0.07, " as the percentage to apply is 7%")
        elif age >= 30:
            print("Outcome: ", inc * 0.15, " as the percentage to apply is 15%")
