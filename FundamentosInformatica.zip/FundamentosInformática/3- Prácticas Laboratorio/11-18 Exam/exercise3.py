#UO281798

n = int(input("Give me a real number: "))                                   # We ask for the number to hold the variable.

while n < 0:                                                                # If the provided number is negative, we'll keep asking for another valid number.
    n = int(input("Please, I need a natural number greater than zero: "))

blank = "   "                         # Create a variable to store a blank space. This is useful as we can define the size of the blank space.

for i in range(0, n):                 # Define the range of the loop.
    print(blank*i, end='*\n')         # For each i in the defined range, we're printing the blank space "i" times, and we'll end with an "*", inserting a new line with \n.
