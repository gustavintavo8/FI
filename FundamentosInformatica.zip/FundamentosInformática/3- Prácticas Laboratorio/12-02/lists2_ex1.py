def list(filename):
    f = open(filename, "r")
    lines = f.readlines()
    for n in range(len(lines)):
        eachline = lines[n]
        lines[n] = eachline.rstrip()
    return lines
    f.close()


print(list("data.txt"))
st = list("data.txt")
st2 = []
for i in st:
    st2.append(int(i))

print(st2)
print(sum(st2))
