def numberstudents(filename):
    f = open(filename, "r")
    lines = f.readlines()
    counter = 0
    for n in range(len(lines)):
        counter = counter + 1
    return counter
    f.close()


def match_surname(line, surname):
    line2 = line.split(" ")
    if line2[0] == surname:
        return True
    line2[1] = line2[1].replace(",", "")
    if line2[1] == surname:
        return True
    return False


def words_name(line):
    line2 = line.split(",")
    n = len(str(line2[1]))
    return n


print(numberstudents("students.txt"))
print(match_surname("Rodriguez Gonzalez, Marcos", "Gonzalez"))

f = open("students.txt", "r")
lines = f.readlines()
a = 0
result = a/len(lines)*100
for n in lines:
    if match_surname(n, "Fernandez"):
        a = a + 1
result = a/len(lines)*100
print(result)

print(words_name("Rodriguez Gonzalez, Marcos"))
