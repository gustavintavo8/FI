a = int(input("Give me the a: "))
b = int(input("Give me the b: "))
if b>0 and a>=0:
    cociente=0
    number=a

    while number>=b and b>0 and a>=0:
        number = number-b
        cociente=cociente+1
    print("Quotient:", cociente)
    print("Reminder:", number)
else:
    print("Invalid values")





