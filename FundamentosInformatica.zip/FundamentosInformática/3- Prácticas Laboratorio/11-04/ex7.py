number = int(input("Give me the number: "))
next=1
numcounter = 1
bignumpos = 1

while next != 0:
    next = int(input("Another number, 0 to finish: "))
    numcounter = numcounter + 1
    if next > number:
        number = next
        bignumpos = numcounter
print("The largest numer is",number, "and it was provided in the position", bignumpos)


