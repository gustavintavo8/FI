x = 1
number = int(input("Introduce a number to calculate its square root: "))
powerX=1
while powerX<=number:
    x=x+1
    powerX=x**2
print("The integer part of the square root of", number, "is",x-1)
