n = int(input("Give me the number: "))
sum = 0
if n>=0:
    for i in range(1, n+1):
        sum = sum + i
    print(sum)

else:
    print("Invalid value")
