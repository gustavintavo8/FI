def rotate_left(array):
    temporal = array[0]
    del array[0]
    array.append(temporal)


array = [1, 2, 3, 4]
print(array)
rotate_left(array)
print(array)
