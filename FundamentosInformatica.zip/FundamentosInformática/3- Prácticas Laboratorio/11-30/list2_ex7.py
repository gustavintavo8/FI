def first_last6(array):
    if array[0] == 6:
        return True
    elif array[len(array)-1] == 6:
        return True
    else:
        return False


array = [7, 4, 6]
print(first_last6(array))
