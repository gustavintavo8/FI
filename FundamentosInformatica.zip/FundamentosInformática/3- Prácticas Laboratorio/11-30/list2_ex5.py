def sum_of_powers(list, n):
    final_sum = 0
    for i in range(0, len(list)):
        a = pow(list[i], n)
        final_sum = final_sum + a
    return final_sum


list = [1, 2, 3]
n = 1

print(sum_of_powers(list, n))
