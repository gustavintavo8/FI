import random

list = []

for i in range(0, 10):
    number = random.randint(1, 20)
    list.append(number)

print(list)

oddcounter = 0
evencounter = 0

for n in list:
    if n % 2 == 0:
        evencounter = evencounter + 1
    else:
        oddcounter = oddcounter+1

print("evencounter: ", evencounter)
print("oddcounter: ", oddcounter)
