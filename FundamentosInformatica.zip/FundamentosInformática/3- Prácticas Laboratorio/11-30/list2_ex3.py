import random

list = []

for i in range(0, 10):
    number = random.randint(1, 20)
    list.append(number)

print(list)

b = list[::-1]

print(b)
