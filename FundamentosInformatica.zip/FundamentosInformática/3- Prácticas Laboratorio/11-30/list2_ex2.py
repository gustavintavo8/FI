import random

list = []

for i in range(0, 10):
    number = random.randint(1, 20)
    list.append(number)

print(list)
th = 10

for i in range(len(list)):
    for w in list:
        if w > th:
            list.remove(w)
newlist = list
print(newlist)
