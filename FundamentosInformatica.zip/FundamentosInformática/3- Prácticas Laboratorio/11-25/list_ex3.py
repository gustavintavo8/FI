def set_zeros(list):
    counter = 0
    for i in range(0, len(list)):
        if list[i] < 0:
            list[i] = 0
            counter = counter + 1
    return counter


list = [1, 2, -3, 4, -2, 6]
print(set_zeros(list))
print(list)
