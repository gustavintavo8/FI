def isPerfect(n):
    sum = 0
    for i in range(1, n):
        if n % i == 0:
            sum = sum + i
    return sum == n


a = int(input("Give the number to check: "))
print(isPerfect(a))
