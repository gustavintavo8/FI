import math


def radius(x, y):
    return math.sqrt(pow(x, 2) + pow(y, 2))


def perimeter(r):
    return 2*math.pi*r


a = int(input("Give me the x position: "))
b = int(input("Give me the y position: "))
r = radius(a, b)
print(perimeter(r))
