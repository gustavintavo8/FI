def succession(b, c, d, k):
    for i in range(0, k+1):
        if i == 0:
            result = b
            kk = b
        if i > 0:
            result = c * kk + d
        kk = result
    return result


b = int(input("gimme b: "))
c = int(input("gimme c: "))
d = int(input("gimme d: "))
k = int(input("gimme k: "))

print(succession(b, c, d, k))


