def index_largest(list):
    indexlarg = 0
    for i in range(0, len(list)):
        if list[i] > indexlarg:
            indexlarg = i
    return indexlarg


# esto está mal xd
list = [1, 2, 3, 5, 3, 4]
print(index_largest(list))
