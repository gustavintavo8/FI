def sumlist(list):
    sum = 0
    for i in list:
        sum = sum + i
    return sum


list = [1, 2, 3, 4, 5, 6]
print(sumlist(list))
print(sum(list))
