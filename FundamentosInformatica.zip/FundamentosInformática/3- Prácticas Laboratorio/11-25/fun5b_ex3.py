def isPerfect(n):
    sum = 0
    for i in range(1, n):
        if n % i == 0:
            sum = sum + i
    return sum == n


thres = int(input("Give me the threshold: "))
for i in range(2, thres):
    if isPerfect(i):
        print(i, end=' ')
