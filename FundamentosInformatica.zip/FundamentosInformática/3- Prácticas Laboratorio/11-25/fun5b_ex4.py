def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True


a = int(input("Give me the number to check: "))
while a > 0:
    xd = is_prime(a)
    print('Is', a, 'prime?', xd)
    a = int(input("Give me the number to check: "))
