def sum_of_powers(list, n):
    final_sum = 0
    for i in range(0, len(list)):
        a = pow(list[i], n)
        final_sum = final_sum + a
    return final_sum


list = [1, 2, 3]
n = 2
print('The sum of the', 'n =', n, 'powers of', list, 'is:', sum_of_powers(list, n))

