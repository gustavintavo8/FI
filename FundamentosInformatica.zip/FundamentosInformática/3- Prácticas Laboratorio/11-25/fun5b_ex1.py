def factorial(n):
    fact = 1
    for i in range(1, n+1):
        fact = fact * i
    return fact


a = int(input("Give me the value: "))
xd = factorial(a)
print('The factorial number of', a, 'is', xd)
