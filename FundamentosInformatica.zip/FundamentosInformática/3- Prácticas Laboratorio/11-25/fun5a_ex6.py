import math


def distance(x, y):
    return math.sqrt(pow(x, 2) + pow(y, 2))


a = int(input("Give me the x position: "))
b = int(input("Give me the y position: "))
print(distance(a, b))
