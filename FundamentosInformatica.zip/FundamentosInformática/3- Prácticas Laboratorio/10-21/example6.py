# LEARNING OUTCOME: Using nested conditions
# IMPLEMENTATION: if c1:
# if c2:
# s1
# else:
# s2
# else:
# if c3:
# s3
# else:
# s4
# DESCRIPTION: This program reads three integer numbers and chooses the
# largest one among them.
number1 = int(input("Type the first number: "))
number2 = int(input("Type the second number: "))
number3 = int(input("Type the third number: "))
if number1 > number2:
    if number1 > number3:
        max = number1;
    else:
        max = number3;
else:
    if number2 > number3:
        max = number2
    else:
        max = number3
print("The largest of %d, %d, %d is: %d"%(number1,number2,number3,max))
