# LEARNING OUTCOME: Use the simple choice (if)
# IMPLEMENTATION: if cond:
# sent
# DESCRIPTION: This program reads an integer number and shows a message
# if it is an even number. In addition, another message
# appears showing the next number.
# If the number is odd, no message is printed.
number = int(input("Type an integer number: "))
if number % 2 == 0:
    print("The number %d is even," %number)
    print("and next number is %d" %(number+1))
