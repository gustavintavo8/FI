name = input("What's your name? ")
n1 = float(input("What's your mark in the 1st exam? "))
n2 = float(input("What's your mark in the 2nd exam? "))

ave = float((n1 + n2) / 2)
pa = (ave >= 5)

print("Your average mark is: ", ave)
print("Do you pass?: ", pa)
