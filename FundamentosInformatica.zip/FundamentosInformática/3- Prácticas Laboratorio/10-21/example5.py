# LEARNING OUTCOME: Using double choice structure (if-else)
# IMPLEMENTATION: if cond:
# sent1
# else:
# sent2
# DESCRIPTION: This program reads a mark (FLOAT) and determines if the
# student passes (>=5) or fails (<5)
mark = float(input("Type your mark: "))
if mark >= 5.0:
    print ("PASS")
else:
    print ("FAIL")
