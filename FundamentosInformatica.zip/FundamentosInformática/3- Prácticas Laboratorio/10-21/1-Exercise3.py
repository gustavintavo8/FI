import math
radius = float(input("Give me the radius: "))
area = math.pi*radius*radius
print("The area of a circumference with radius", radius, "is", area)
