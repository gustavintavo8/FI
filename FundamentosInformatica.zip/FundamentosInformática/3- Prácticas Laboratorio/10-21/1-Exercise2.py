name = input("What's your name? ")
n1 = float(input("What's your mark in the 1st exam? "))
n2 = float(input("What's your mark in the 2nd exam? "))

ave = float((n1 + n2) / 2)
pa = (ave >= 5)

print("The average mark of", name, "is: ", ave)
print("Pass mark: ", pa)
