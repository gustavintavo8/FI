a = float(input("Give me the first coefficient:"))
b = float(input("Give me the independent term:"))

if (a == 0) and (b != 0):
    print("There isn't solution")
    
elif (a == 0) and (b == 0):
    print("X can be any number")

elif a != 0:
    solution = b/a
    print("X is equal to %f" % solution)
