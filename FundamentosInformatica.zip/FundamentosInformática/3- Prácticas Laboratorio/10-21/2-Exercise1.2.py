x = 0
if x >= 0:
 x=x+1
if x >= 1:
 x=x+2
print("x=%d" %x)
