# LEARNING OUTCOME: Using double choice structure (if-else)
# IMPLEMENTATION: if cond:
# sent1
# else:
# sent2
# DESCRIPTION: This program reads an integer number and print a message
# indicating if this number is even or odd.
number = int(input("Type an integer number: "))
if number % 2 == 0:
    print("The number %d is even" %number)
else:
    print("The number %d is odd" %number)
