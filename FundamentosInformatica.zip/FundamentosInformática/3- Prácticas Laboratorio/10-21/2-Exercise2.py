a = int(input("Give me the first number: "))
b = int(input("Give me the second number: "))
c = int(input("Give me the third number: "))
if a < b < c:
    print("They are on ascending order")
else:
    print("They are not in ascending order")
