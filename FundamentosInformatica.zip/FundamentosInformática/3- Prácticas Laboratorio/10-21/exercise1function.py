def name():
    n = input("Give me a name")
    return n
def mark():
    mark = float(input("Give me a mark"))
    return mark
def average(m1, m2):
    result = (m1+m2)/2
    return result
n = name()
m1 = mark()
m2 = mark()
avg = average(m1,m2)
passed = avg>=5
print(passed)
