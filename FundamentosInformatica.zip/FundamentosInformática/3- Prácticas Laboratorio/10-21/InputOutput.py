a = input("Give me a number: ")
aNumber = float(a)
print(type(a))
print(type(aNumber))
