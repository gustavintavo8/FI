import math
a = int(input("Give me an a coefficient: "))
b = int(input("Give me a b coefficient: "))
c = int(input("Give me a c coefficient: "))

if ((b ** 2) - 4 * a * c) > 0:
    s1 = ((-b+math.sqrt(b*b-4*a*c))/(2*a))
    s2 = ((-b-math.sqrt(b*b-4*a*c))/(2*a))
    print("There are two possible solutions")
    print("The first one is", s1, "and the second one is", s2)

else:
    print("There are not (real) possible solutions.")

