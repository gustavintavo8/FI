meters = float(input("Give me the meters: "))

inches = meters*39.3701
feet = meters*3.281
yards = meters*1.09361

print(meters, "are", inches, "inches,", feet, "feet and", yards, "yards")
