a = int(input("Give me the first number: "))
b = int(input("Give me the second number: "))
c = int(input("Give me the third number: "))
d = int(input("Give me the fourth number: "))
e = int(input("Give me the fifth number: "))

print("The largest one is", max(a, b, c, d, e))
