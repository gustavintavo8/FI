# LEARNING OUTCOME: Use multiple choice structure
# IMPLEMENTATION: if cond1:
# sent1
# elif cond2:
# sent2
# …
# elif condN:
# sentN
# else:
# sentF
# DESCRIPTION: This program reads a decimal number representing the
# mark of a student in a test, and determines the
# alphabetical label associated with that mark. If you
# enter a number outside the range [0-10], the mark is
# invalid and the program warns you.
n = float(input("Type your mark: "))
if 0 <= n < 5:
    print("FAIL")
elif 5 <= n < 7:
    print("PASS")
elif 7 <= n < 9:
    print("GOOD")
elif 9 <= n <= 10:
    print("VERY GOOD")
else:
    print("INVALID MARK ")
