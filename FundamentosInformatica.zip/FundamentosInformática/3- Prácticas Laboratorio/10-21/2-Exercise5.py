import math
a = float(input("Give me the number: "))
choose = str(input("Press a to calculate the square of the number, b to calculate the cube, or c to calculate the double: "))

if choose == "a":
    print(math.sqrt(a))
elif choose == "b":
    print(a**3)
elif choose == "c":
    print(a*2)
else:
    print("Invalid option")

