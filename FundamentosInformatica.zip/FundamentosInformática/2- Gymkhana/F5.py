n = 1
for i in range(-1, -11, -2):
    n = n * i
print(n)
