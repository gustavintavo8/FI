b = 'uzhtnfltnh'
input_string = input()
res = b > input_string
print(res)
