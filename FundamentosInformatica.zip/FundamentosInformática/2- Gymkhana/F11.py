s = 9901
o = 7
counter = 0
p = 9950
for i in range(s, p, o):
    counter += 1
    print(counter)
