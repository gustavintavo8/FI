price = 136
vat = 21.3
print(round(price+price*(vat/100), 2))
print(round(price*(1+(vat/100)), 2))

