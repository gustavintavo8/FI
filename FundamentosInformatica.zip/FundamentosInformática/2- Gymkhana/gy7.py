my_list = ['a', 'b', 'z' , 'c', 'a', 'b']

alf = sorted(my_list)[-1]
print(alf)
