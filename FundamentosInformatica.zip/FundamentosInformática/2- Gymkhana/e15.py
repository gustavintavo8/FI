v1 = 30
v2 = 20
v3 = 10

if v1 > v2:
    temp = v1
    v1 = v2
    v2 = temp
print(v1, v2, v3)

if v2 > v3:
    temp = v2
    v2 = v3
    v3 = temp
print(v1, v2, v3)

if v1 > v2:
    temp = v1
    v1 = v2
    v2 = temp

print(v1, v2, v3)
