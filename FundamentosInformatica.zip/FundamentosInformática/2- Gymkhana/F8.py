for i in range(10, -3, 2):
    for j in range(-5, 1, 2):
        print(i*j)
