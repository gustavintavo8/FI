print(list(range(2,5,2)))
