
a = -10

if 5 * a - 5 * 2 // 2 > -30:
    print('Option 1')
else:
    print('Option 2')
