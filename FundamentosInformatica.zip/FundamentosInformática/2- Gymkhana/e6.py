v1 = 1
v2 = 10
v3 = 8
res = not (v1 > 9 or v2 > 4 and not (v3 != 8))
print(res)
