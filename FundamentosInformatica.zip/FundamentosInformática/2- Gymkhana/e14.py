x = 6

result = '> '
if x > 7:
    result += 'a '
elif x // 2 == 3:
    result += 'b '
if x + 2 > 6:
    result += 'c '

print(result)
v2 = 3
v1 = 23
var = v2 > v1
