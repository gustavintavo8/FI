name = 'benjamin'

print(chr(ord('benjamin'[0]) - 32) + 'benjamin'[1:len('benjamin')])
