print(8 < 10 or 2 > 7)
