y = [0.31, 6.64, -1.4, 3.97, -2.27, 1.24, -4.69, 3]
a = len(y)
print(a)
boo = isinstance(y[-1], int)
print(boo)
