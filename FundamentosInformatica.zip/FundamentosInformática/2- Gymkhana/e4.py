print(True or (1 or 8 > 5))
