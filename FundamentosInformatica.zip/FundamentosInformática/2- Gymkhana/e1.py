l = 46
x = 50
q = -6

outcome = l <= q and q <= x
