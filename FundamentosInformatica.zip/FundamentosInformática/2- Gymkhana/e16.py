k = 3
n = 34
c = 22
if k > 9 and n > c ** 5 and False or k > n ** c:
    print('a')
elif k % 2 == 0 and c % 5 == 1:
    print('b')
elif c ** 4 > k or n * k > (c + n):
    print('c')
else:
    print('d')
