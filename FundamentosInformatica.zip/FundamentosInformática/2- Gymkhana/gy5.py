m = 34
y = [5, 6, 7, 8, 34]


print(m in y)
