w = 'potcbkra'

print(w[0] == w[0].lower())

