c = 61
q = 254
e = 16
counter = 0
for i in range(c, q, e):
    counter += 1
    if i == 253:
        print(counter)
    print()
