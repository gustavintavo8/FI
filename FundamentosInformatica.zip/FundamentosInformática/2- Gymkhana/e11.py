row = 4
# column = 'B'
column = 2

is_white = row % 2 != 0
print(is_white)
