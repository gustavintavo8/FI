m = 'zbqfr'
v = ['fzdpxyzi', 'ptbwjks', 'hliuj', 'peiirv', 'zbqfr']

a = m in v
print(a)
