((v_i*(v_n+v_o))**2) < (v_s//v_w)
