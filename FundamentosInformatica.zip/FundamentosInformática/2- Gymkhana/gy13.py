p = 'odcebhntdakjwu'
y = 'bh'
t = 'dnx'

p.replace(y, t)
