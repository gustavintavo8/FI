m = 128
c = 21
a = 107
for i in range(a, m, c):
    print("xd")
