v1 = 1
v2 = 5
v3 = 5
res = not (v1 > 1 or v2 < 1 and v3 == 5)
print(res)
