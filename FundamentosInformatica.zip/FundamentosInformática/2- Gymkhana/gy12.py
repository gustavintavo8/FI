b = 'Alphabet Aerobics'
v = ['Alphabet Aerobics']

print(b in v)
