a = 849825331
q = 0
while a > 0:
    d = a % 10
    a = a // 10
    q = q + d

