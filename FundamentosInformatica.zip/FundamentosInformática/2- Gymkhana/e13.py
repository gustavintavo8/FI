n = 19
if n < 6 and n % 2 != 0:
    print(1)
elif n < 13:
    print(2)
elif n < 22 and n % 2 == 0:
    print(3)
elif n < 25:
    print(4)
else:
    print(5)
