n = 73
counter = 0
while n >= 0:
    n = n - 5
    counter = counter + 3
counter = counter + 20
print(counter)
