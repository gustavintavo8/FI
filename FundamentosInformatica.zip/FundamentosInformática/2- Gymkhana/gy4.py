a = [9, 10]
o = [5, 6, 7]


o.extend(a)
print(o)
