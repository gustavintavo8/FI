n = 56
counter = 0
while n > -39:
    if n > 0 and n % 2 == 0:
        n = n // 2
    else:
        n = n - 5
    counter = counter + 1
counter -= 4
print(counter)
