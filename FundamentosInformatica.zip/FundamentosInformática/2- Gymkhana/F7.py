n = 0
g = 0
u = 11
for i in range(1, u, 1):
    if i % 3 == 0:
        g = g + 1
    else:
        n = n + g
print(n)
