q = 1
k = 0
u = 9
while q < u:
    q = q * 3
    k = k + 1
print(k)
