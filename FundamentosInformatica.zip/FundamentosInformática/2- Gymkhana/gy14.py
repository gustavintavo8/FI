phonenumber = '+24 683547887'
c, n = phonenumber.split(' ')
print(c)
print(n)
