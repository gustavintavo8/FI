v = 3
y = 302
d = 10
for i in range(v, y, d):
    print()
