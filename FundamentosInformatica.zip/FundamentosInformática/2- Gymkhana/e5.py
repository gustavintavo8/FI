print(2 < 9 and (False and True or False))
