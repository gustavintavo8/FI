j = 7
u = 11
o = 23
t = 5

print(o > j+t and o <= u+t)
