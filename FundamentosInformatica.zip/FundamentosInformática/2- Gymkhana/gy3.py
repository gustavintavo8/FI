i = 'kcblk'
x = ['wdskdt', 'jzdcuq', 'zspfwp', 'ktgoryf', 'qjyue']
print(x)
x.append(i)
print(x)
